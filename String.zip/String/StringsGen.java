//Assignment 6
//Zhou, Xiaolu
//elaine07
//Lou, Jiadong
//jiadonglou

import tester.*;
interface ILoList<T> {
    //helper function for isSorted that determine whether the
    //given string comes before all elements in the list.
    boolean isSortedHelper(T s, IComparator<T> c);
    //is the list sorted?
    boolean isSorted(IComparator<T> c);
    //helper function for sort that insert a string into a sorted list
    //and returns a new sorted list
    ILoList<T> mergeHelper(T s, IComparator<T> c);
    //to merge two sorted list into one sorted list
    ILoList<T> merge(ILoList<T> that, IComparator<T> c);
    //is the list an empty list?
    boolean isEmpty();
    //produce a sorted list
    ILoList<T> sort(IComparator<T> c);
    //helper function for sort that insert a string into a sorted list
    ILoList<T> sortHelper(T s, IComparator<T> c);
    //whether the two lists contain the same data in the same order
    boolean sameList(ILoList<T> s);
    //is the list same as that empty list?
    boolean sameEmpty(Empty<T> s);
    //is the list same as that nonempty list?
    boolean sameConslos(Cons<T> s);
    
}
//to represent a empty list
class Empty<T> implements ILoList<T> {
    //helper function for isSorted that determine whether the
    //given string comes before all elements in the list.
    public boolean isSortedHelper(T s, IComparator<T> c) {
        return true;
    }
    //is the list sorted?
    public boolean isSorted(IComparator<T> c) {
        return true;
    }
    //helper function for sort that insert a string into a sorted list
    //and returns a new sorted list
    public ILoList<T> mergeHelper(T s, IComparator<T> c) {
        return new Cons<T>(s, this);
    }
    //to merge two sorted list into one sorted list
    public ILoList<T> merge(ILoList<T> that, IComparator<T> c) {
        return this;
    };
    //is the list an empty list?
    public boolean isEmpty() {
        return true;
    }
    //produce a sorted list
    public ILoList<T> sort(IComparator<T> c) {
        return this;
    };
    //helper function for sort that insert a string into a sorted list
    public ILoList<T> sortHelper(T s, IComparator<T> c) {
        return new Cons<T>(s, this);
    };
    //whether the two lists contain the same data in the same order
    public boolean sameList(ILoList<T> s) {
        return s.isEmpty();
    };
    //is the list same as that empty list?
    public boolean sameEmpty(Empty<T> s) {
        return true;
    };
    //is the list same as that nonempty list?
    public boolean sameConslos(Cons<T> s) {
        return false;
    }
}
//to represent a list of strings
class Cons<T> implements ILoList<T> {
    T first;
    ILoList<T> rest;
    //constructor
    Cons(T first, ILoList<T> rest) {
        this.first = first;
        this.rest = rest;
    }
    //helper function for isSorted that determine whether the
    //given string comes before all elements in the list.
    public boolean isSortedHelper(T s, IComparator<T> c) {
        return c.compare(s, this.first) < 0 &&
                this.rest.isSortedHelper(s, c);
    }
    //is the list sorted?
    public boolean isSorted(IComparator<T> c) {
        return this.rest.isSortedHelper(this.first, c) &&
                this.rest.isSorted(c);
    }
    //helper function for sort that insert a string into a sorted list
    //and returns a new sorted list
    public ILoList<T> mergeHelper(T s, IComparator<T> c) {
        if (c.compare(s, this.first) < 0) {
            return new Cons<T>(s, this);
        } 
        else {
            return new Cons<T>(this.first, this.rest.mergeHelper(s, c));
        }
    }
    //to merge two sorted list into one sorted list
    public ILoList<T> merge(ILoList<T> that, IComparator<T> c) {
        if (that.isEmpty()) {
            return this;
        } 
        else {
            if (((Cons<T>)that).rest.isEmpty()) {
                return this.mergeHelper(((Cons<T>)that).first, c);
            } 
            else {
                return this.mergeHelper(((Cons<T>)that).first, c).merge(
                        ((Cons<T>)that).rest, c);
            }       
        }
    }
    //is the list an empty list?
    public boolean isEmpty() {
        return false;
    }
    //produce a sorted list
    public ILoList<T> sort(IComparator<T> c) {
        return this.rest.sort(c).sortHelper(this.first, c);
    }
    //helper function for sort that insert a string into a sorted list
    public ILoList<T> sortHelper(T s, IComparator<T> c) {
        if (c.compare(s, this.first) < 0) {
            return new Cons<T>(s, this);
        }
        else {
            return new Cons<T>(this.first, this.rest.sortHelper(s, c));
            
        }
    }
    //whether the two lists contain the same data in the same order
    public boolean sameList(ILoList<T> s) {
        return s.sameConslos(this);
    }
    //is the list same as that empty list?
    public boolean sameEmpty(Empty<T> s) {
        return false;
    }
    //is the list same as that nonempty list?
    public boolean sameConslos(Cons<T> s) {
        return this.first.equals(s.first) &&
                this.rest.sameList(s.rest);
    }
    
}
//to represent string comparators
interface IComparator<T> {
    int compare(T t1, T t2);
}
//compare strings lexicographically
class StringLexCompGen implements IComparator<String> {
    public int compare(String s1, String s2) {
        return s1.compareTo(s2);
    }
}
//compare the Strings by their length from the shortest to the longest
class StringLengthCompGen implements IComparator<String> {
    public int compare(String s1, String s2) {
        return s1.length() - s2.length();
    }
}

//examples
class ExampleString {
    ILoList<String> mt = new Empty<String>();
    ILoList<String> a = new Cons<String>("aa", 
                new Cons<String>("cc",
                    new Cons<String>("f",
                        mt)));
    ILoList<String> b = new Cons<String>("b",
                new Cons<String>("d",
                    new Cons<String>("g",
                            mt)));
    ILoList<String> c = new Cons<String>("aa", 
            new Cons<String>("b",
                new Cons<String>("cc", 
                        new Cons<String>("d",
                                new Cons<String>("f",
                                        new Cons<String>("g", this.mt))))));
    ILoList<String> d = new Cons<String>("test", 
                new Cons<String>("not", new Cons<String>("sorted", mt)));
    ILoList<String> e = new Cons<String>("i",
                new Cons<String>("am", new Cons<String>("Elaine", mt)));
    ILoList<String> f = new Cons<String>("test", new Cons<String>("merge", mt));
    
    IComparator<String> lex = new StringLexCompGen();
    IComparator<String> len = new StringLengthCompGen();

    
    // test for isSortedHelper
    boolean testisSortedHelper(Tester t) {
        return t.checkExpect(this.a.isSortedHelper("string", this.lex), false) &&
                t.checkExpect(this.b.isSortedHelper("a", this.lex), true) &&
                t.checkExpect(this.d.isSortedHelper("s", this.lex), false) &&
                t.checkExpect(this.mt.isSortedHelper("a", this.lex), true);
    }
    // test for isSorted
    boolean testisSorted(Tester t) {
        return t.checkExpect(this.a.isSorted(this.lex), true) &&
                t.checkExpect(this.a.isSorted(this.len), false) &&
                t.checkExpect(this.e.isSorted(this.len), true) &&
                t.checkExpect(this.e.isSorted(this.lex), false) &&
                t.checkExpect(this.mt.isSorted(this.len), true) &&
                t.checkExpect(this.mt.isSorted(this.lex), true);
            
    }
    // test for mergeHelper
    boolean testmergeHelper(Tester t) {
        return t.checkExpect(this.a.mergeHelper("ddd", this.lex), new Cons<String>("aa", 
                                                      new Cons<String>("cc",
                                                        new Cons<String>("ddd",
                                                          new Cons<String>("f",
                                                            new Empty<String>()))))) &&
                t.checkExpect(this.b.mergeHelper("a", this.lex), new Cons<String>("a",
                                                    new Cons<String>("b",
                                                     new Cons<String>("d",
                                                      new Cons<String>("g",
                                                       new Empty<String>()))))) &&
                t.checkExpect(this.e.mergeHelper("computerscience", this.len), new Cons<String>("i",
                                    new Cons<String>("am", new Cons<String>("Elaine", 
                                            new Cons<String>("computerscience", mt))))) &&
                t.checkExpect(this.mt.mergeHelper("a", this.lex), new Cons<String>("a", mt)) &&
                t.checkExpect(this.mt.mergeHelper("aaa", this.len), new Cons<String>("aaa", mt));
    }
    // test for merge
    boolean testmerge(Tester t) {
        return t.checkExpect(this.b.merge(this.a, this.lex), this.c) &&
                t.checkExpect(this.a.merge(this.mt, this.lex), this.a) &&
                t.checkExpect(this.mt.merge(this.mt, this.len), this.mt) &&
                t.checkExpect(this.a.merge(this.mt,  this.len), this.a) &&
                t.checkExpect(this.e.merge(this.f, this.len), new Cons<String>("i",
                            new Cons<String>("am", new Cons<String>("test", 
                                    new Cons<String>("merge", 
                                            new Cons<String>("Elaine", this.mt))))));
    }
        
    // test for isEmpty
    boolean testisEmpty(Tester t) {
        return t.checkExpect(this.a.isEmpty(), false) &&
                t.checkExpect(this.e.isEmpty(), false) &&
                t.checkExpect(this.mt.isEmpty(), true);
    }

    // test for SameList
    boolean testSameList(Tester t) {
        return t.checkExpect(this.a.sameList(this.a), true) &&
                t.checkExpect(this.e.sameList(this.b), false) &&
                t.checkExpect(this.mt.sameList(this.mt), true) &&
                t.checkExpect(this.mt.sameList(this.a), false) &&
                t.checkExpect(this.a.sort(this.len).sameList(this.a), false) &&
                t.checkExpect(this.a.sort(this.lex).sameList(this.a), true);
    }

    // test for SameEmpty
    boolean testSameEmpty(Tester t) {
        return t.checkExpect(this.mt.sameEmpty(new Empty<String>()), true) &&
                t.checkExpect(this.a.sameEmpty(new Empty<String>()), false) &&
                t.checkExpect(this.e.sameEmpty(new Empty<String>()), false);
    }

    // test for SameConslos
    boolean testSameConslos(Tester t) {
        return t.checkExpect(this.a.sameConslos(new Cons<String>("aa", 
                new Cons<String>("cc",
                    new Cons<String>("f",
                        new Empty<String>())))), true ) &&
                t.checkExpect(this.a.sameConslos(new Cons<String>("b",
                    new Cons<String>("d",
                            new Cons<String>("g",
                                    new Empty<String>())))), false) &&
                t.checkExpect(this.mt.sameConslos(new Cons<String>("b",
                        new Cons<String>("d",
                                new Cons<String>("g",
                                        new Empty<String>())))), false);
    }
    
}