//Assignment 6
//Zhou, Xiaolu
//elaine07
//Lou, Jiadong
//jiadonglou

import tester.*;
//to represent a list of string
interface ILoString {
    //helper function for isSorted that determine whether the
    //given string comes before all elements in the list.
    boolean isSortedHelper(String s, IStringsCompare c);
    //is the list sorted?
    boolean isSorted(IStringsCompare c);
    //helper function for sort that insert a string into a sorted list
    //and returns a new sorted list
    ILoString mergeHelper(String s, IStringsCompare c);
    //to merge two sorted list into one sorted list
    ILoString merge(ILoString that, IStringsCompare c);
    //is the list an empty list?
    boolean isEmpty();
    //produce a sorted list
    ILoString sort(IStringsCompare c);
    //helper function for sort that insert a string into a sorted list
    ILoString sortHelper(String s, IStringsCompare c);
    //whether the two lists contain the same data in the same order
    boolean sameList(ILoString s);
    //is the list same as that empty list?
    boolean sameEmpty(MtLoString s);
    //is the list same as that nonempty list?
    boolean sameConslos(ConsLoString s);
}
//to represent a empty list
class MtLoString implements ILoString {
    //helper function for isSorted that determine whether the
    //given string comes before all elements in the list.
    public boolean isSortedHelper(String s, IStringsCompare c) {
        return true;
    }
    //is the list sorted?
    public boolean isSorted(IStringsCompare c) {
        return true;
    }
    //to insert a single string to a sorted list
    public ILoString mergeHelper(String s, IStringsCompare c) {
        return new ConsLoString(s, this);
    }
    //to merge two sorted list into one sorted list
    public ILoString merge(ILoString that, IStringsCompare c) {
        return new MtLoString();
    }
    //is the list an empty list?
    public boolean isEmpty() {
        return true;
    }
    //produce a sorted list
    public ILoString sort(IStringsCompare c) {
        return new MtLoString();
    }
    //helper function for sort that insert a string into a sorted list
    //and returns a new sorted list
    public ILoString sortHelper(String s, IStringsCompare c) {
        return new ConsLoString(s, this);
    }
    //whether the two lists contain the same data in the same order
    public boolean sameList(ILoString s) {
        return s.isEmpty();
    }
    //is the list same as that empty list?
    public boolean sameEmpty(MtLoString s) {
        return true;
    }
    //is the list same as that nonempty list?
    public boolean sameConslos(ConsLoString s) {    
        return false;
    }
   
}
//to represent a non-empty list
class ConsLoString implements ILoString {
    String first;
    ILoString rest;
    //constructor
    ConsLoString(String first, ILoString rest) {
        this.first = first;
        this.rest = rest;
    }
    //is the list an empty list?
    public boolean isEmpty() {
        return false;
    }
    //helper function for isSorted that determine whether the
    //given string comes before all elements in the list.
    public boolean isSortedHelper(String s, IStringsCompare c) {
        return c.comesBefore(s, this.first) &&
                this.rest.isSortedHelper(s, c);
    }
    //is the list sorted?
    public boolean isSorted(IStringsCompare c) {
        return this.rest.isSortedHelper(this.first, c) &&
                this.rest.isSorted(c);
    }
    //to insert a single string into a sorted list
    public ILoString mergeHelper(String s, IStringsCompare c) {
        if (c.comesBefore(s, this.first)) {
            return new ConsLoString(s, this);
        } 
        else {
            return new ConsLoString(this.first, this.rest.mergeHelper(s, c));
        }
    }
    //to merge two sorted list into one sorted list
    public ILoString merge(ILoString that, IStringsCompare c) {
        if (that.isEmpty()) {
            return this;
        } 
        else {
            if (((ConsLoString)that).rest.isEmpty()) {
                return this.mergeHelper(((ConsLoString)that).first, c);
            } 
            else {
                return this.mergeHelper(((ConsLoString)that).first, c).merge(
                        ((ConsLoString)that).rest, c);
            }
        }
    }
    //produce a sorted list
    public ILoString sort(IStringsCompare c) {
        return this.rest.sort(c).sortHelper(this.first, c);
    }
    //helper function for sort that insert a string into a sorted list
    public ILoString sortHelper(String s, IStringsCompare c) {
        if (c.comesBefore(s, this.first)) {
            return new ConsLoString(s, this);
        }
        else {
            return new ConsLoString(this.first, this.rest.sortHelper(s, c));
            
        }
    }
    //whether the two lists contain the same data in the same order
    public boolean sameList(ILoString s) {
        return s.sameConslos(this);
    }
        
    //is the list same as that empty list?
    public boolean sameEmpty(MtLoString s) {
        return false;
    }
    //is the list same as that nonempty list?
    public boolean sameConslos(ConsLoString s) {    
        return this.first.equals(s.first) &&
                this.rest.sameList(s.rest);
    }
}

//to represent string comparators
interface IStringsCompare {
    boolean comesBefore(String s1, String s2);
    
}
//compare strings lexicographically 
class StringLexComp implements IStringsCompare {
    public boolean comesBefore(String s1, String s2) {
        return s1.compareTo(s2) < 0;
    }
}
//compare the Strings by their length from the shortest to the longest
class StringLengthComp implements IStringsCompare {
    public boolean comesBefore(String s1, String s2) {
        return s1.length() <= s2.length();
    }
}
//examples
class ExamplesString {
    ILoString mt = new MtLoString();
    ILoString a = new ConsLoString("aa", 
                    new ConsLoString("cc",
                        new ConsLoString("f",
                            new MtLoString())));
    ILoString b = new ConsLoString("b",
                    new ConsLoString("d",
                        new ConsLoString("g",
                                new MtLoString())));
    ILoString c = new ConsLoString("aa", 
            new ConsLoString("b",
                    new ConsLoString("cc", 
                            new ConsLoString("d",
                                    new ConsLoString("f",
                                            new ConsLoString("g", this.mt))))));
    ILoString d = new ConsLoString("test", 
                    new ConsLoString("not", new ConsLoString("sorted", mt)));
    ILoString e = new ConsLoString("i",
                    new ConsLoString("am", new ConsLoString("Elaine", mt)));
    ILoString f = new ConsLoString("test", new ConsLoString("merge", mt));
    
    IStringsCompare lex = new StringLexComp();
    IStringsCompare len = new StringLengthComp();
    //test issortedHelper
    boolean testisSortedHelper(Tester t) {
        return t.checkExpect(this.a.isSortedHelper("string", this.lex), false) &&
                t.checkExpect(this.b.isSortedHelper("a", this.lex), true) &&
                t.checkExpect(this.d.isSortedHelper("s", this.lex), false) &&
                t.checkExpect(this.mt.isSortedHelper("a", this.lex), true);
    }
    //test isSorted
    boolean testisSorted(Tester t) {
        return t.checkExpect(this.a.isSorted(this.lex), true) &&
                t.checkExpect(this.a.isSorted(this.len), false) &&
                t.checkExpect(this.e.isSorted(this.len), true) &&
                t.checkExpect(this.e.isSorted(this.lex), false) &&
                t.checkExpect(this.mt.isSorted(this.len), true) &&
                t.checkExpect(this.mt.isSorted(this.lex), true);
                
    }
    //test mergeHelper
    boolean testmergeHelper(Tester t) {
        return t.checkExpect(this.a.mergeHelper("ddd", this.lex), new ConsLoString("aa", 
                                                          new ConsLoString("cc",
                                                            new ConsLoString("ddd",
                                                              new ConsLoString("f",
                                                                mt))))) &&
                t.checkExpect(this.b.mergeHelper("a", this.lex), new ConsLoString("a",
                                                        new ConsLoString("b",
                                                         new ConsLoString("d",
                                                          new ConsLoString("g",
                                                           mt))))) &&
                t.checkExpect(this.e.mergeHelper("computerscience", len), new ConsLoString("i",
                                        new ConsLoString("am", new ConsLoString("Elaine", 
                                                new ConsLoString("computerscience", this.mt)))));
    }
    //test merge
    boolean testmerge(Tester t) {
        return t.checkExpect(this.b.merge(this.a, new StringLexComp()), this.c) &&
                t.checkExpect(this.a.merge(this.mt, this.lex), this.a) &&
                t.checkExpect(this.mt.merge(this.mt, this.lex), this.mt) &&
                t.checkExpect(this.mt.merge(this.mt, this.len), this.mt) &&
                t.checkExpect(this.a.merge(this.mt,  this.len), this.a) &&
                t.checkExpect(this.e.merge(this.f, this.len), new ConsLoString("i",
                            new ConsLoString("am", new ConsLoString("test", 
                                    new ConsLoString("merge", new ConsLoString("Elaine", 
                                            this.mt))))));
    }
    
    // test for isEmpty
    boolean testisEmpty(Tester t) {
        return t.checkExpect(this.a.isEmpty(), false) &&
                t.checkExpect(this.e.isEmpty(), false) &&
                t.checkExpect(this.mt.isEmpty(), true);
    }
    
    // test for SameList
    boolean testSameList(Tester t) {
        return t.checkExpect(this.a.sameList(this.a), true) &&
                t.checkExpect(this.e.sameList(this.b), false) &&
                t.checkExpect(this.mt.sameList(this.mt), true) &&
                t.checkExpect(this.mt.sameList(this.a), false) &&
                t.checkExpect(this.a.sort(this.len).sameList(this.a), false) &&
                t.checkExpect(this.a.sort(this.lex).sameList(this.a), true);
    }
    
    // test for SameEmpty
    boolean testSameEmpty(Tester t) {
        return t.checkExpect(this.mt.sameEmpty(new MtLoString()), true) &&
                t.checkExpect(this.a.sameEmpty(new MtLoString()), false) &&
                t.checkExpect(this.e.sameEmpty(new MtLoString()), false);
    }
    
    // test for SameConslos
    boolean testSameConslos(Tester t) {
        return t.checkExpect(this.a.sameConslos(new ConsLoString("aa",
                     new ConsLoString("cc",
                        new ConsLoString("f",
                            new MtLoString())))), true) &&
                t.checkExpect(this.a.sameConslos(new ConsLoString("i",
                        new ConsLoString("am", new ConsLoString("Elaine", this.mt)))), false) &&
                t.checkExpect(this.mt.sameConslos(new ConsLoString("a", this.mt)), false);
    }
}
