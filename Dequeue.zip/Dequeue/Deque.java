//Assignment 8
//Zhou, Xiaolu
//elaine07
//Lou, Jiadong
//jiadonglou


// To represent predicates (boolean-valued questions)
interface IPred<T> {
    // applies the predicate
    boolean apply(T t);
}

// To represent a double-ended queue (deque)
class Deque<T> {
    Sentinel<T> header;
    // constructor
    Deque() {
        this.header = new Sentinel<T>();
    }
    // convenience constructor
    Deque(Sentinel<T> header) {
        this.header = header;
    }
    
    // Counts the number of data-storing nodes in this deque
    // i.e. all nodes that are not the sentinel
    int size() {
        return this.header.countNodes();
    }
    
    // Adds a new node with the given data at the head of the deque
    // EFFECT: adds a node and modifies links between nodes
    void addAtHead(T data) {
        new Node<T>(data, this.header.next, this.header);
    }
    
    // Adds a new node with the given data at the tail of the deque
    // EFFECT: adds a node and modifies links between nodes
    void addAtTail(T data) {
        new Node<T>(data, this.header, this.header.prev);
    }
    
    // Removes the node at the head of the deque and returns the
    // data that was removed
    // EFFECT: removes a node and modifies links between nodes
    T removeFromHead() {
        return this.header.next.remove();
    }
    
    // Removes the node at the tail of the deque and returns the
    // data that was removed
    // EFFECT: removes a node and modifies links between nodes
    T removeFromTail() {
        return this.header.prev.remove();
    }
    
    // Returns the first node whose data satisfies the given predicate
    // If no nodes are found, returns the sentinel header
    ANode<T> find(IPred<T> pred) {
        return this.header.next.find(pred);
    }
    
    // Removes the given node
    // If the given node is the sentinel header, do nothing
    void removeNode(ANode<T> node) {
        if (node != this.header) {
            node.remove();
        }
    }
}

// To represent a node in a deque
abstract class ANode<T> {
    ANode<T> prev;
    ANode<T> next;
    
    // Counts all nodes connected to this one, excluding this node
    // Always invoked on the sentinel header
    int countNodes() {
        return this.next.countNodesHelp();
    }
    
    // Helper for countNodes()
    // Counts nodes until it reaches the sentinel
    abstract int countNodesHelp();
    
    // Removes this node and returns the data in that node
    // EFFECT: deletes a node and modifies links between nodes
    abstract T remove();
    
    // Finds the first node whose data satisfies the given predicate
    // If no such node is found, returns the sentinel header
    abstract ANode<T> find(IPred<T> p);
}

// To represent a sentinel node
class Sentinel<T> extends ANode<T> {
    Sentinel() {
        this.prev = this;
        this.next = this;
    }
    
    // Helper for ANode.countNodes()
    // In the sentinel case, returns 0 (no connected nodes)
    public int countNodesHelp() {
        return 0;
    }
    
    // Removes this node
    // Because this is a sentinel header, it cannot be removed
    public T remove() {
        throw new RuntimeException("Cannot remove from an empty deque.");
    }
    
    // Finds the first node that satisfies the given predicate
    // If this runs on the sentinel node, then we have gone through
    // the whole deque and should return the sentinel node (i.e. this)
    public ANode<T> find(IPred<T> p) {
        return this;
    }
}

// To represent a data node
class Node<T> extends ANode<T> {
    T data;
    
    Node(T data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
    
    // EFFECT: modifies the two given nodes
    Node(T data, ANode<T> next, ANode<T> prev) {
        if (prev == null || next == null) {
            throw new IllegalArgumentException("Cannot pass null nodes to node constructor");
        }
        
        // update the information for this node
        this.data = data;        
        this.prev = prev;
        this.next = next;
        
        // update the given nodes to link to this node
        prev.next = this;
        next.prev = this;
    }
    
    // helper for ANode.countNodes()
    public int countNodesHelp() {
        return 1 + this.next.countNodesHelp();
    }
    
    // Removes this node and returns the data that was removed
    // EFFECT: deletes this node and all links to this node
    public T remove() {
        this.prev.next = this.next;
        this.next.prev = this.prev;
        return this.data;
    }
    // Finds the first node whose data satisfies the given predicate
    // If the current node does not satisfy the predicate, check the
    // next node in the deque.
    public ANode<T> find(IPred<T> p) {
        if (p.apply(this.data)) {
            return this;
        }
        else {
            return this.next.find(p);
        }
    }
}