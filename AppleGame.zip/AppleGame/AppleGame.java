//Assignment 5
//Zhou, Xiaolu
//elaine07
//Lou, Jiadong
//jiadonglou

import tester.*; // The tester library
import javalib.worldimages.*; // images, like RectangleImage or OverlayImages
import javalib.funworld.*; // the abstract World class and the big-bang library
import javalib.colors.*; // Predefined colors (Red, Green, Yellow, Blue, Black, White)
import java.awt.Color;
import java.util.Random; // general colors (as triples of red,green,blue values)

// to represent list of Apple
interface ILoApple {
    // helper function for onTick
    ILoApple onTickHelper(Posn b);

    // to overlay multiple Apples
    WorldImage overlayAppleImage();

    // helper function to count scores
    int countScoreHelper(Posn b);
}

// to represent an empty list of
class MtLoApple implements ILoApple {
    // helper function for onTick
    public ILoApple onTickHelper(Posn b) {
        return this;
    }

    // to overlay multiple Apples
    public WorldImage overlayAppleImage() {
        return new RectangleImage(new Posn(200, 200), 0, 0, new White());
    }

    // helper function to count scores
    public int countScoreHelper(Posn b) {
        return 0;
    }
}

class ConsLoApple implements ILoApple {
    Apple first;
    ILoApple rest;

    ConsLoApple(Apple first, ILoApple rest) {
        this.first = first;
        this.rest = rest;
    }

    // helper function for onTick
    public ILoApple onTickHelper(Posn b) {
        if (this.first.caughtApple(b)) {
            return (new ConsLoApple(this.first.randomPosn(400), this.rest.onTickHelper(b)));
        } 
        else {
            return (new ConsLoApple(this.first.fall(400, 400), this.rest.onTickHelper(b)));
        }
    }

    // to overlay multiple Apples
    public WorldImage overlayAppleImage() {
        return new OverlayImages(this.first.appleImage(), this.rest.overlayAppleImage());
    }

    // helper function to count scores
    public int countScoreHelper(Posn b) {
        if (this.first.caughtApple(b)) {
            return 1 + this.rest.countScoreHelper(b);
        } 
        else if (this.first.onTheGround(400)) {
            return -1 + this.rest.countScoreHelper(b);
        } 
        else {
            return 0 + this.rest.countScoreHelper(b);
        }
    }

}

// to represent a Apple
class Apple {
    Posn center;
    String type;

    // The constructor
    Apple(Posn center, String type) {
        this.center = center;
        this.type = type;
    }

    // to move the apple down
    public Apple moveDown() {
        return new Apple(new Posn(this.center.x, this.center.y + 20), this.type);
    }

    // to determine if the apple is on the ground
    boolean onTheGround(int height) {
        return (this.center.y >= height);
    }

    // produce a new Apple in a random location
    public Apple randomPosn(int max) {
        return new Apple(new Posn(new Random().nextInt(max), 0), this.type);
    }

    // to compute the next Apple
    Apple fall(int width, int height) {
        if (this.onTheGround(height)) {
            return this.randomPosn(width);
        } 
        else {
            return this.moveDown();
        }
    }

    // to graph the world image
    WorldImage appleImage() {
        if (this.type.equals("red")) {
            return (new FromFileImage(this.center, "red-apple.png"));
        } 
        else if (this.type.equals("small-red")) {
            return (new FromFileImage(this.center, "small-red-apple.png"));
        } 
        else if (this.type.equals("yellow-apple")) {
            return (new FromFileImage(this.center, "yellow-apple.png"));
        } 
        else {
            return new RectangleImage(new Posn(200, 200), 0, 0, new White());
        }
    }

    // to determine if Apple is caught in the basket
    public boolean caughtApple(Posn b) {
        return (Math.sqrt((Math.pow(b.x - this.center.x, 2) + 
                Math.pow(b.y - this.center.y, 2))) <= 35);
    }

}

// to represent a Basket
class Basket {
    Posn center;
    int size;

    // The constructor
    Basket(Posn center, int size) {
        this.center = center;
        this.size = size;
    }

    // to move the basket on key
    public Basket moveOnKey(String ke) {
        if (ke.equals("left")) {
            return new Basket(new Posn((this.center.x - 50), this.center.y), this.size);
        } 
        else {
            if (ke.equals("right")) {
                return new Basket(new Posn((this.center.x + 50), this.center.y), this.size);
            } 
            else {
                return this;
            }
        }
    }

    // represent the image of the basket
    WorldImage basketImage() {
        return new RectangleImage(new Posn(this.center.x, this.center.y), 
                this.size, this.size, new Black());
    }

}

// to represent a Apple Game
class AppleGame extends World {
    int width = 400;
    int height = 400;
    ILoApple a;
    Basket b;
    int score;

    // the Constructor
    public AppleGame(ILoApple a, Basket b, int score) {
        this.a = a;
        this.score = score;
        this.b = b;
        this.score = this.score + this.a.countScoreHelper(this.b.center);

    }

    // to produce a new AppleGame
    public AppleGame onTick() {
        return new AppleGame(this.a.onTickHelper(this.b.center), this.b, this.score);
    }

    // display the background image
    public WorldImage appleTree = new FromFileImage(new Posn(200, 200), "apple-tree.png");

    // display the background image,apple image, and basket image
    public WorldImage makeImage() {
        return new OverlayImages(this.appleTree,
                new OverlayImages(this.a.overlayAppleImage(), 
                        new OverlayImages(this.b.basketImage(),
                        new TextImage(new Posn(350, 50), Integer.toString(this.score), 20, 4, 
                                Color.black))));
    }

    // represent the world key event
    public AppleGame onKeyEvent(String ke) {
        return new AppleGame(this.a, this.b.moveOnKey(ke), this.score);

    }

    // to represent the world ends
    public WorldEnd worldEnds() {
        if (this.score > 9) {
            return new WorldEnd(true, new OverlayImages(this.makeImage(),
                    new TextImage(new Posn(200, 150), "Congratulations!You Won", Color.white)));
        }
        if (this.score < -4) {
            return new WorldEnd(true, new OverlayImages(this.makeImage(),
                    new TextImage(new Posn(200, 150), "Sorry You Lost", Color.white)));
        } 
        else {
            return new WorldEnd(false, this.makeImage());
        }
    }

}

// example class for AppleGame
class ExameplesAppleGame {
    Apple a1 = new Apple(new Posn(200, 50), "red");
    Apple a2 = new Apple(new Posn(100, 100), "small-red");
    Apple a3 = new Apple(new Posn(300, 0), "yellow-apple");
    Apple a4 = new Apple(new Posn(200, 70), "red");
    Apple a5 = new Apple(new Posn(100, 120), "small-red");
    Apple a6 = new Apple(new Posn(300, 20), "yellow-apple");

    Basket b1 = new Basket(new Posn(200, 350), 50);

    ILoApple empty = new MtLoApple();
    ILoApple loa1 = new ConsLoApple(a1, empty);
    ILoApple loa2 = new ConsLoApple(a2, loa1);
    ILoApple loa = new ConsLoApple(a3, loa2);
    ILoApple loaNext = new ConsLoApple(a6, new ConsLoApple(a5, new ConsLoApple(a4, empty)));

    AppleGame world1 = new AppleGame(loa, b1, 0);
    AppleGame world2 = new AppleGame(loaNext, b1, 0);
    boolean runAnimation = this.world1.bigBang(400, 400, 0.3);

    // Apple Class
    // test for moveDown
    boolean testMoveDown(Tester t) {
        return t.checkExpect(this.a1.moveDown(), new Apple(new Posn(200, 70), "red"));
    }

    // test for onTheGround
    boolean testOnTheGround(Tester t) {
        return t.checkExpect(this.a1.onTheGround(50), true) &&
                t.checkExpect(this.a1.onTheGround(500), false);
    }

    // test for randomPosn
    boolean testRandomPosn(Tester t) {
        return t.checkRange(a1.randomPosn(30).center.x, 0, 200) &&
                t.checkRange(a2.randomPosn(40).center.y, 0, 200);
    }

    // test for fall
    boolean testFall(Tester t) {
        return t.checkExpect(this.a1.fall(400, 400), new Apple(new Posn(200, 70), "red"));
    }

    // test for appleImage
    boolean testAppleImage(Tester t) {
        return t.checkExpect(this.a1.appleImage(), new FromFileImage(new Posn(200, 50), 
                                                        "red-apple.png"))
                && t.checkExpect(this.a2.appleImage(), new FromFileImage(new Posn(100, 100), 
                                                        "small-red-apple.png"))
                && t.checkExpect(this.a3.appleImage(), new FromFileImage(new Posn(300, 0), 
                                                         "yellow-apple.png"))
                && t.checkExpect(new Apple(new Posn(1, 1), "").appleImage(),
                        new RectangleImage(new Posn(200, 200), 0, 0, new White()));
    }

    // test for Caught Apple
    boolean testCaughtApple(Tester t) {
        return t.checkExpect(this.a1.caughtApple(new Posn(200, 60)), true)
                && t.checkExpect(this.a1.caughtApple(new Posn(400, 400)), false);
    }

    // Basket Class
    // test for moveOnKey
    boolean testMoveOnKey(Tester t) {
        return t.checkExpect(this.b1.moveOnKey("left"), 
                new Basket(new Posn(150, 350), 50))
                && t.checkExpect(this.b1.moveOnKey("right"), 
                        new Basket(new Posn(250, 350), 50));
    }

    // test for basketImage
    boolean testBasketImage(Tester t) {
        return t.checkExpect(this.b1.basketImage(), 
                new RectangleImage(new Posn(200, 350), 50, 50, new Black()));
    }

    // interface ILoApple
    // test for onTickHelper
    boolean testOnTickHelper(Tester t) {
        return t.checkExpect(this.loa.onTickHelper(b1.center), loaNext);
    }

    // test for overlayAppleImage
    boolean testOverlayAppleImage(Tester t) {
        return t.checkExpect(this.loa1.overlayAppleImage(),
                new OverlayImages(new FromFileImage(new Posn(200, 50), "red-apple.png"),
                        new RectangleImage(new Posn(200, 200), 0, 0, new White())));
    }

    // test for countScoreHelper
    boolean testCountScore(Tester t) {
        return t.checkExpect(loa.countScoreHelper(new Posn(200, 350)), 0)
                && t.checkExpect(this.loa.countScoreHelper(new Posn(200, 50)), 1)
                && t.checkExpect(new ConsLoApple(new Apple(new Posn(0, 500), "red"), 
                        new MtLoApple())
                        .countScoreHelper(new Posn(200, 50)), -1);
    }

    // AppleGame Class
    // test for onTick
    boolean testOnTick(Tester t) {
        return t.checkExpect(this.world1.onTick(), world2);
    }

    // test for makeImage
    boolean testMakeImage(Tester t) {
        return t.checkExpect(
                new AppleGame(loa1,
                        b1, 0)
                                .makeImage(),
                new OverlayImages(new FromFileImage(new Posn(200, 200), "apple-tree.png"),
                        new OverlayImages(
                                new OverlayImages(new FromFileImage(new Posn(200, 50), 
                                        "red-apple.png"),
                                        new RectangleImage(new Posn(200, 200), 0, 0, 
                                                new White())),
                                new OverlayImages(new RectangleImage(new Posn(200, 350), 50, 50, 
                                        new Black()),
                                        new TextImage(new Posn(350, 50), Integer.toString(0), 
                                                20, 4, Color.black)))));
    }

    // test for onKeyEvent
    boolean testOnKeyEvent(Tester t) {
        return t.checkExpect(this.world1.onKeyEvent("left"), 
                new AppleGame(loa, new Basket(new Posn(150, 350), 50), 0)) &&
                t.checkExpect(this.world1.onKeyEvent("right"),
                        new AppleGame(loa, new Basket(new Posn(250, 350), 50), 0));
    }

    // test for worldEnds
    boolean testWorldEnds(Tester t) {
        return t.checkExpect(new AppleGame(loa, b1, 15).worldEnds(),
                new WorldEnd(true,
                        new OverlayImages(new AppleGame(loa, b1, 15).makeImage(),
                                new TextImage(new Posn(200, 150), "Congratulations!You Won", 
                                        Color.white)))) &&
                t.checkExpect(new AppleGame(loa, b1, -6).worldEnds(),
                        new WorldEnd(true,
                                new OverlayImages(new AppleGame(loa, b1, -6).makeImage(),
                                        new TextImage(new Posn(200, 150), "Sorry You Lost", 
                                                Color.white)))) &&
                t.checkExpect(new AppleGame(loa, b1, 0).worldEnds(),
                        new WorldEnd(false, new AppleGame(loa, b1, 0).makeImage()));
    }

}
