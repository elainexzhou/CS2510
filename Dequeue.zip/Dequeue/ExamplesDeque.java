import tester.*;

// To represent a person
// (Not relevant to the problem, but it's just another data type for a sample deque)
class Person {
    String name;
    int age;
    Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
}

// To represent general "Not" predicates
class Not<T> implements IPred<T> {
    IPred<T> p;
    Not(IPred<T> p) {
        this.p = p;
    }
    
    public boolean apply(T t) {
        return !p.apply(t);
    }
}

// To represent predicates for testing
class ShortStr implements IPred<String> {
    public boolean apply(String s) {
        return s.length() < 3;
    }
}

class OldPerson implements IPred<Person> {
    public boolean apply(Person p) {
        return p.age >= 40;
    }
}

class Even implements IPred<Integer> {
    public boolean apply(Integer i) {
        return i % 2 == 0;
    }
}

// For example data and testing methods
class ExamplesDeque {
    Deque<Integer> deque1;
    
    Deque<String> deque2;
    Sentinel<String> s0;
    ANode<String> s1;
    ANode<String> s2;
    ANode<String> s3;
    ANode<String> s4;
    
    Deque<Person> deque3;
    Sentinel<Person> p0;
    ANode<Person> p1;
    ANode<Person> p2;
    ANode<Person> p3;
    ANode<Person> p4;
    ANode<Person> p5;
    
    Person ann = new Person("Ann", 22);
    Person bob = new Person("Bob", 31);
    Person carl = new Person("Carl", 40);
    Person dan = new Person("Dan", 19);
    Person ethel = new Person("Ethel", 65);
    
    IPred<String> shortStrings = new ShortStr();
    IPred<String> longStrings = new Not<String>(this.shortStrings);
    IPred<Person> oldies = new OldPerson();
    IPred<Integer> evens = new Even();
    
    // to initialize all fields to a known value;
    void initialize() {
        this.deque1 = new Deque<Integer>();
        
        this.s0 = new Sentinel<String>();
        this.s1 = new Node<String>("abc", this.s0, this.s0);
        this.s2 = new Node<String>("bcd", this.s0, this.s1);
        this.s3 = new Node<String>("cde", this.s0, this.s2);
        this.s4 = new Node<String>("def", this.s0, this.s3);
        this.deque2 = new Deque<String>(this.s0);
        
        this.p0 = new Sentinel<Person>();
        this.p1 = new Node<Person>(this.dan, this.p0, this.p0);
        this.p2 = new Node<Person>(this.bob, this.p0, this.p1);
        this.p3 = new Node<Person>(this.ethel, this.p0, this.p2);
        this.p4 = new Node<Person>(this.ann, this.p0, this.p3);
        this.p5 = new Node<Person>(this.carl, this.p0, this.p4);
        this.deque3 = new Deque<Person>(this.p0);
    }
    
    // test construction/modification of deques/nodes
    void testConstruction(Tester t) {
        // initialize
        this.initialize();
        // check to make sure it initialized correctly
        t.checkExpect(this.deque2.header.next, this.s1);
        t.checkExpect(this.deque2.header.prev.next, this.s0);
        t.checkExpect(this.deque3.header.next.next.prev.next, this.p2);
        t.checkExpect(this.deque3.header.prev.prev, this.p4);
    }
    
    // test Deque.size()
    void testSize(Tester t) {
        // initialize
        this.initialize();
        // test Deque.size() method
        t.checkExpect(this.deque1.size(), 0);
        t.checkExpect(this.deque2.size(), 4);
        t.checkExpect(this.deque3.size(), 5);
    }
    
    
    // test Deque.addAtHead()
    void testAddHead(Tester t) {
        // initialize
        this.initialize();
        // test Deque.addAtHead() method
        Deque<String> test = new Deque<String>();
        test.addAtHead("def");
        test.addAtHead("cde");
        test.addAtHead("bcd");
        test.addAtHead("abc");
        t.checkExpect(this.deque2, test);
    }
    
    // test Deque.addAtTail()
    void testAddTail(Tester t) {
        // initialize
        this.initialize();
        // test Deque.addAtTail()method
        Deque<Person> test = new Deque<Person>();
        test.addAtTail(this.dan);
        test.addAtTail(this.bob);
        test.addAtTail(this.ethel);
        test.addAtTail(this.ann);
        test.addAtTail(this.carl);
        t.checkExpect(this.deque3, test);
    }
    
    
    // test Deque.removeFromHead()
    void testRemoveHead(Tester t) {
        // initialize
        this.initialize();
        // mutate; let's make deque2 empty for simplicity's sake,
        // and remove 3 elements from deque3
        this.deque2.removeFromHead();
        this.deque2.removeFromHead();
        this.deque2.removeFromHead();
        this.deque2.removeFromHead();
        
        this.deque3.removeFromHead();
        this.deque3.removeFromHead();
        this.deque3.removeFromHead();
        
        // let's make some sample data to compare our mutated deque's to
        Deque<String> deque2Test = new Deque<String>();
        
        Sentinel<Person> p0Test = new Sentinel<Person>();
        ANode<Person> p1Test = new Node<Person>(this.ann, p0Test, p0Test);
        ANode<Person> p2Test = new Node<Person>(this.carl, p0Test, p1Test);
        Deque<Person> deque3Test = new Deque<Person>(p0Test);
        
        t.checkException(new RuntimeException("Cannot remove from an empty deque."),
                this.deque1, "removeFromHead");
        t.checkExpect(this.deque2, deque2Test);
        t.checkExpect(this.deque3, deque3Test);
    }
    
    // test Deque.removeFromTail()
    void testRemoveTail(Tester t) {
        // initialize
        this.initialize();
        
        // mutate; this time, we'll empty out deque3 and remove 1 element of deque2
        this.deque2.removeFromTail();
        
        this.deque3.removeFromTail();
        this.deque3.removeFromTail();
        this.deque3.removeFromTail();
        this.deque3.removeFromTail();
        this.deque3.removeFromTail();
        
        // once again, set up sample test data
        Sentinel<String> s0Test = new Sentinel<String>();
        ANode<String> s1Test = new Node<String>("abc", s0Test, s0Test);
        ANode<String> s2Test = new Node<String>("bcd", s0Test, s1Test);
        ANode<String> s3Test = new Node<String>("cde", s0Test, s2Test);
        Deque<String> deque2Test = new Deque<String>(s0Test);
        
        Deque<Person> deque3Test = new Deque<Person>();
        
        t.checkException(new RuntimeException("Cannot remove from an empty deque."),
                deque1, "removeFromTail");
        t.checkExpect(this.deque2, deque2Test);
        t.checkExpect(this.deque3, deque3Test);
    }
    
    
    // to test Deque.find()
    void testFind(Tester t) {
        // initialize
        this.initialize();
        // test
        t.checkExpect(this.deque1.find(this.evens), new Sentinel<Integer>());
        t.checkExpect(this.deque2.find(this.shortStrings), this.s0);
        t.checkExpect(this.deque2.find(this.longStrings), this.s1);
        t.checkExpect(this.deque3.find(this.oldies), this.p3);
    }
 // to test Deque.removeNode()
    void testRemove(Tester t) {
        // initialize
        this.initialize();
        // mutate
        this.deque1.removeNode(this.deque1.header);
        this.deque2.removeNode(this.s1);
        this.deque2.removeNode(this.s3);
        this.deque3.removeNode(this.p3);
        this.deque3.removeNode(this.p0);
        this.deque3.removeNode(this.p5);
        // re-create data for check-expect purposes
        Deque<Integer> deque1Test = new Deque<Integer>();
        
        Sentinel<String> s0Test = new Sentinel<String>();
        ANode<String> s1Test = new Node<String>("bcd", s0Test, s0Test);
        ANode<String> s2Test = new Node<String>("def", s0Test, s1Test);
        Deque<String> deque2Test = new Deque<String>(s0Test);
        
        Sentinel<Person> p0Test = new Sentinel<Person>();
        ANode<Person> p1Test = new Node<Person>(this.dan, p0Test, p0Test);
        ANode<Person> p2Test = new Node<Person>(this.bob, p0Test, p1Test);
        ANode<Person> p3Test = new Node<Person>(this.ann, p0Test, p2Test);
        Deque<Person> deque3Test = new Deque<Person>(p0Test);
        
        t.checkExpect(this.deque1, deque1Test);
        t.checkExpect(this.deque2, deque2Test);
        t.checkExpect(this.deque3, deque3Test);
    }
}